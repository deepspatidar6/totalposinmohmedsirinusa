export const environment = {
    _api  : 'http://localhost:8080/'
};
