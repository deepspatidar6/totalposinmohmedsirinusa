import { Component } from '@angular/core';

@Component({
  selector: 'app-purchase-pending-report',
  templateUrl: './purchase-pending-report.component.html',
  styleUrls: ['./purchase-pending-report.component.scss']
})
export class PurchasePendingReportComponent {

}
