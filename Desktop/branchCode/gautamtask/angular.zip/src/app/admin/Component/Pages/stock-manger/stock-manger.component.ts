import { Component } from '@angular/core';

@Component({
  selector: 'app-stock-manger',
  templateUrl: './stock-manger.component.html',
  styleUrls: ['./stock-manger.component.scss']
})
export class StockMangerComponent {

}
