import { Component } from '@angular/core';

@Component({
  selector: 'app-ordershipped',
  templateUrl: './ordershipped.component.html',
  styleUrls: ['./ordershipped.component.scss']
})
export class OrdershippedComponent {

}
