import { Component } from '@angular/core';

@Component({
  selector: 'app-addproduction-order-report',
  templateUrl: './addproduction-order-report.component.html',
  styleUrls: ['./addproduction-order-report.component.scss']
})
export class AddproductionOrderReportComponent {

}
