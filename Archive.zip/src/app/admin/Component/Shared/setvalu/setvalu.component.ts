import { Component } from '@angular/core';

@Component({
  selector: 'app-setvalu',
  templateUrl: './setvalu.component.html',
  styleUrls: ['./setvalu.component.scss']
})
export class SetvaluComponent  {


}
