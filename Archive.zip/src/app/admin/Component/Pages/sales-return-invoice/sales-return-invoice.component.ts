import { Component } from '@angular/core';

@Component({
  selector: 'app-sales-return-invoice',
  templateUrl: './sales-return-invoice.component.html',
  styleUrls: ['./sales-return-invoice.component.scss']
})
export class SalesReturnInvoiceComponent {

}
