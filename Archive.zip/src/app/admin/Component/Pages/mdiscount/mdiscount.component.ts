import { Component } from '@angular/core';

@Component({
  selector: 'app-mdiscount',
  templateUrl: './mdiscount.component.html',
  styleUrls: ['./mdiscount.component.scss']
})
export class MdiscountComponent {

}
