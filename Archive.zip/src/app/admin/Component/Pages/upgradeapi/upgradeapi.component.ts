import { Component } from '@angular/core';

@Component({
  selector: 'app-upgradeapi',
  templateUrl: './upgradeapi.component.html',
  styleUrls: ['./upgradeapi.component.scss']
})
export class UpgradeapiComponent {

}
