import { Component } from '@angular/core';

@Component({
  selector: 'app-closeout',
  templateUrl: './closeout.component.html',
  styleUrls: ['./closeout.component.scss']
})
export class CloseoutComponent {

}
