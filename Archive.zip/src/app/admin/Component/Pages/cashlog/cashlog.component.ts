import { Component } from '@angular/core';

@Component({
  selector: 'app-cashlog',
  templateUrl: './cashlog.component.html',
  styleUrls: ['./cashlog.component.scss']
})
export class CashlogComponent {

}
