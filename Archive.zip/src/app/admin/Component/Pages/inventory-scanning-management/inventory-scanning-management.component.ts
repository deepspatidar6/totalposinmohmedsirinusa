import { Component } from '@angular/core';

@Component({
  selector: 'app-inventory-scanning-management',
  templateUrl: './inventory-scanning-management.component.html',
  styleUrls: ['./inventory-scanning-management.component.scss']
})
export class InventoryScanningManagementComponent {

}
