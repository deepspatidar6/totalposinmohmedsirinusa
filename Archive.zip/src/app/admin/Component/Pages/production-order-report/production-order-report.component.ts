import { Component } from '@angular/core';
@Component({
  selector: 'app-production-order-report',
  templateUrl: './production-order-report.component.html',
  styleUrls: ['./production-order-report.component.scss']
})
export class ProductionOrderReportComponent {

}
