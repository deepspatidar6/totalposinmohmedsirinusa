import { Component } from '@angular/core';

@Component({
  selector: 'app-prepareordere',
  templateUrl: './prepareordere.component.html',
  styleUrls: ['./prepareordere.component.scss']
})
export class PrepareordereComponent {

}
